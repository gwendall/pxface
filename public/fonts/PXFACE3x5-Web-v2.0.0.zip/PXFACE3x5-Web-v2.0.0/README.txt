PXFACE 3x5 — Version 2.0.0

A proportional five-pixel-high display font generated from the same glyphs as pxface.com.

PACKAGE
Self-hosted web fonts and CSS.

RECOMMENDED USE
Serve PXFACE3x5-Regular.woff2 with pxface-3x5.css. Keep WOFF only if you need a legacy fallback.

Do not install both the TTF and OTF versions. They represent the same family and
style, so installing both can create duplicate-family warnings.

WEB
Copy the web font files and pxface-3x5.css into the same directory, then link the
stylesheet or copy its @font-face rule. WOFF2 is the recommended browser format;
WOFF is included only as a legacy fallback.

DESKTOP
macOS: open PXFACE3x5-Regular.ttf, then choose Install Font in Font Book.
Windows: right-click PXFACE3x5-Regular.ttf, then choose Install or Install for all users.
Linux: copy the TTF or OTF to ~/.local/share/fonts and run fc-cache -f.

LICENSE
Font software is OFL-1.1 with Reserved Font Name PXFACE. Documents and graphics made with the font are not placed under the OFL. See OFL.txt.

The font contains glyph outlines and metrics. Use https://pxface.com for pixel
gap, depth, random colors, padding, canvas ratios, and editable per-pixel SVG.

Documentation: https://pxface.com/font
